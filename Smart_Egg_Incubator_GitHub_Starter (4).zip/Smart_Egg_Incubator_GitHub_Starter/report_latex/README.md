# LaTeX report

`main.tex` is the starter source. Compile it from this folder using a LaTeX distribution. The image paths are relative to this folder (`../assets/...`). Add the compiled PDF here as `Smart_Automatic_Egg_Incubator_Report.pdf` after compiling. Replace all `To be measured` / `To be verified` entries with actual observations before submission.
