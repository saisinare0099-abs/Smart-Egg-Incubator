Add original, unaltered project evidence to the matching folders. The two supplied photos are already included under assets/images. Do not claim that missing stages were photographed.
