Upload the exact Arduino sketch used by the final physical prototype here. Verify pin assignments, relay logic, thresholds, and sensor type before publishing.
