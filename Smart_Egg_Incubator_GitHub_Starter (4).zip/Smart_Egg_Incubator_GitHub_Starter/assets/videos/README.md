Add the actual one-minute project demonstration video here. Do not use stock or AI-generated footage as project evidence.
